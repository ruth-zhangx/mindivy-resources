#!/usr/bin/env python3
"""Type Checking — Python 类型标注实战

Python 是动态类型语言，但类型标注 (Type Hints) 让它在「写代码时」
就能发现类型错误。本文件涵盖以下核心概念：
  - 基本类型标注（str, int, float, bool, list, dict）
  - Optional 和 Union（可选值和联合类型）
  - TypedDict（字典结构定义）
  - Protocol（结构化子类型——Python 的「接口」）
  - Generic（泛型——类型安全的容器）
  - mypy 静态检查

学习路径：
  1. 基本标注——给函数签名加上类型
  2. Optional / Union——处理多种可能的类型
  3. TypedDict——给 dict 做类型约束
  4. Protocol——鸭子类型的静态检查版本
  5. Generic——类型安全的通用容器
"""

from typing import (
    TypeVar,
    Generic,
    Protocol,
    TypedDict,
    Optional,
    Union,
    Callable,
    Any,
)

# ── 1. 基本类型标注 ─────────────────────────────────────────────────

# 给函数加上类型标注——Python 运行时不会强制执行，
# 但 mypy/pyright 等静态检查器会在「写代码时」发现类型错误。


def greet(name: str, times: int = 1) -> str:
    """生成问候语——带完整类型标注的例子。

    标注告诉调用者：
      - name 必须是 str（传入 int 会触发 mypy 警告）
      - times 必须是 int（默认 1）
      - 返回值一定是 str

    读标注就能理解函数的「契约」——不需要读实现。
    """
    return f"Hello, {name}! " * times


def average(numbers: list[float]) -> float:
    """计算平均值——list[X] 表示「元素类型为 X 的列表」。

    list[float] 读作「float 列表」——mypy 会检查你不能
    把 str 放到这个列表里（如果你在别处构建了这个列表的话）。
    """
    if not numbers:
        return 0.0
    return sum(numbers) / len(numbers)


def get_user_name(user: dict[str, Any]) -> str:
    """从 dict 中提取用户名——dict[str, Any] 的常见用法。

    但 dict[str, Any] 太宽松了——你不知道 dict 里有什么字段。
    更好的做法是下一节的 TypedDict。
    """
    return str(user.get("name", "unknown"))


# ── 2. Optional 和 Union ───────────────────────────────────────────


def find_user(user_id: int) -> Optional[dict[str, Any]]:
    """根据 ID 查找用户——可能返回 None。

    Optional[X] 等价于 Union[X, None]——
    明确告诉调用者：「这个函数可能返回 None，你要处理这种情况」。

    对比：没有 Optional 标注的代码，调用者可能忘记检查 None，
    导致 TypeError: 'NoneType' object is not subscriptable。
    """
    users = {1: {"name": "Alice"}, 2: {"name": "Bob"}}
    return users.get(user_id)  # .get() 可能返回 None


def process_value(value: Union[int, str]) -> str:
    """处理 int 或 str——使用 Union 标注联合类型。

    Union[int, str] 表示「接受 int 或 str」。
    函数内部通常需要 isinstance 判断来区分处理逻辑。

    自 Python 3.10 起，可以用 int | str 替代 Union[int, str]——
    语法更简洁，语义完全相同。
    """
    if isinstance(value, int):
        return f"处理数字: {value * 2}"
    else:
        return f"处理字符串: {value.upper()}"


# ── 3. TypedDict — 字典的结构定义 ──────────────────────────────────


class User(TypedDict):
    """定义 User 字典的结构。

    TypedDict 是 Python 3.8 引入的——它不创建实际的类，
    只是告诉类型检查器「一个 User 字典应该有哪些字段」。

    注意：TypedDict 只在检查时生效，运行时它就是一个普通的 dict。
    你不能用 isinstance(obj, User) 来判断类型。
    """
    id: int
    name: str
    email: str
    age: int


class UserSummary(TypedDict, total=False):
    """使用 total=False 表示所有字段都是可选的。

    total=False 适合「部分更新」的场景——只提供需要修改的字段。
    默认是 total=True（所有字段必填）。
    """
    name: str
    email: str
    age: int


def create_welcome_email(user: User) -> str:
    """生成欢迎邮件——参数标注为 User TypedDict。

    类型检查器会验证调用者传入的 dict 包含 id, name, email, age 四个字段。
    不再需要手动检查 if "email" in user。
    """
    return f"""
    欢迎 {user['name']}！

    您的账号信息：
      ID:    {user['id']}
      邮箱:  {user['email']}
      年龄:  {user['age']}
    """


def update_user(user_id: int, changes: UserSummary) -> None:
    """部分更新用户——changes 的字段都是可选的。

    total=False 让 UserSummary 中所有字段可选——
    调用者可以只传 {'age': 30} 来更新年龄。
    """
    # 实际项目中这里会更新数据库
    print(f"更新用户 {user_id}: {changes}")


# ── 4. Protocol — 结构化子类型（Python 的「接口」）──────────────────


class Flyable(Protocol):
    """定义「能飞的东西」的协议。

    Protocol 是 Python 3.8 引入的结构化子类型——
    任何有 fly() 方法的类自动满足 Flyable 协议，
    不需要显式继承或注册。

    这与传统的「名义子类型」（class Bird(Flyable)）完全不同——
    这是 Python 鸭子类型的静态检查版本：
      「如果它走起来像鸭子，叫起来像鸭子，那它就是鸭子。」
    """

    def fly(self) -> str: ...


class Bird:
    """Bird 没有继承 Flyable，但有 fly() 方法——所以它满足 Flyable 协议。"""
    def fly(self) -> str:
        return "翅膀飞行"


class Airplane:
    """Airplane 也没有继承 Flyable，但有 fly() 方法。"""
    def fly(self) -> str:
        return "喷气引擎飞行"


def take_off(flyable: Flyable) -> str:
    """接收任何满足 Flyable 协议的对象。

    不关心传入的是 Bird 还是 Airplane——只要有 fly() 方法。
    这就是「面向接口而非实现」编程。
    """
    return f"起飞！飞行方式: {flyable.fly()}"


# ── 5. Generic — 类型安全的通用容器 ────────────────────────────────


T = TypeVar("T")  # 类型变量——泛型的核心


class Stack(Generic[T]):
    """通用栈——类型安全的 LIFO 容器。

    Generic[T] 让 Stack 成为一个泛型类——
    Stack[int] 只能放 int，Stack[str] 只能放 str。

    对比：如果不用泛型，只能标注 list[Any]——
    类型检查器无法保证你不会把 str push 到 int 栈中。
    """

    def __init__(self) -> None:
        self._items: list[T] = []

    def push(self, item: T) -> None:
        """推入元素——类型 T 由实例化时决定。"""
        self._items.append(item)

    def pop(self) -> Optional[T]:
        """弹出顶部元素——栈为空时返回 None。"""
        if not self._items:
            return None
        return self._items.pop()

    def peek(self) -> Optional[T]:
        """查看顶部元素但不弹出。"""
        if not self._items:
            return None
        return self._items[-1]

    def __len__(self) -> int:
        return len(self._items)


def first_and_last(items: list[T]) -> tuple[T, T]:
    """泛型函数——接收任何类型的列表，返回同类型的元组。

    类型变量 T 在函数签名中的每次出现必须一致：
      list[T] → tuple[T, T]
    输入 str 列表 → 返回 str 元组。类型安全。
    """
    if len(items) < 1:
        raise ValueError("列表不能为空")
    return items[0], items[-1]


# ── 使用示例 ─────────────────────────────────────────────────────────


if __name__ == "__main__":
    print("=" * 60)
    print("Type Checking — 类型标注演示")
    print("=" * 60)

    # 1. 基本类型
    print("\n1. 基本类型标注:")
    print(f"   greet('Claude', 3) = {greet('Claude', 3)!r}")
    print(f"   average([1.0, 2.0, 3.5]) = {average([1.0, 2.0, 3.5])}")

    # 2. Optional
    print("\n2. Optional:")
    result = find_user(1)
    # 类型检查器会强制你处理 None 的情况
    if result is not None:
        print(f"   找到用户 1: {result}")
    print(f"   查找不存在的用户 99: {find_user(99)}")

    # 3. Union
    print("\n3. Union:")
    print(f"   process_value(42) = {process_value(42)}")
    print(f"   process_value('hello') = {process_value('hello')}")

    # 4. TypedDict
    print("\n4. TypedDict:")
    alice: User = {
        "id": 1,
        "name": "Alice",
        "email": "alice@example.com",
        "age": 25,
    }
    print(create_welcome_email(alice))

    # 5. Protocol — 鸭子类型
    print("\n5. Protocol（结构化子类型）:")
    print(f"   {take_off(Bird())}")
    print(f"   {take_off(Airplane())}")

    # 6. Generic
    print("\n6. Generic（泛型容器）:")
    int_stack: Stack[int] = Stack()
    int_stack.push(10)
    int_stack.push(20)
    int_stack.push(30)
    print(f"   Stack 大小: {len(int_stack)}")
    print(f"   pop: {int_stack.pop()}")
    print(f"   peek: {int_stack.peek()}")

    str_stack: Stack[str] = Stack()
    str_stack.push("hello")
    str_stack.push("world")
    print(f"   Str Stack pop: {str_stack.pop()}")

    # 类型变量——first_and_last
    nums = [1, 2, 3, 4, 5]
    first, last = first_and_last(nums)
    print(f"   first_and_last({nums}) = ({first}, {last})")

    print("\n💡 运行 mypy 做静态检查:")
    print("   pip install mypy")
    print("   mypy type_checking.py")
    print("\n   期望结果: Success: no issues found in 1 source file")
