#!/usr/bin/env python3
"""CSV Analyzer — 数据分析脚本

读取 CSV 文件并进行基本统计分析，涵盖以下核心概念：
  - csv 模块的使用（DictReader/reader）
  - 基本统计量（平均值、中位数、最值、标准差）
  - 数据类型检测与转换
  - 命令行参数（argparse）与文件处理

学习路径：
  1. load_csv() — 读取 CSV 并自动检测列类型
  2. ColumnStats — 统计计算的核心逻辑
  3. analyze() — 组装分析结果
  4. 理解数值精度与异常值处理
"""

import argparse
import csv
import math
import statistics
from collections import Counter
from pathlib import Path
from typing import Any


# ── 数据加载：读取 CSV 并自动检测列类型 ──────────────────────────────


def detect_type(values: list[str]) -> str:
    """检测一列的数据类型——通过尝试转换来判断。

    检测顺序很重要：先试 int，再试 float，最后 fallback 到 str。
    因为 "42" 同时满足 int 和 float——先 int 保证整数列不会被
    误判为浮点列。

    Args:
        values: 列的所有字符串值（不含表头）。

    Returns:
        类型字符串: "int", "float", 或 "str"。
    """
    # 取前 20 个非空值来判断类型（避免全量扫描大文件）
    samples = [v for v in values[:20] if v.strip()]

    if not samples:
        return "str"  # 全空列 → 当作字符串

    # 尝试 int：所有样本都能解析为整数？
    if all(_is_int(v) for v in samples):
        return "int"

    # 尝试 float：所有样本都能解析为浮点数？
    if all(_is_float(v) for v in samples):
        return "float"

    return "str"


def _is_int(s: str) -> bool:
    """判断字符串是否可以解析为整数。"""
    try:
        int(s)
        return True
    except ValueError:
        return False


def _is_float(s: str) -> bool:
    """判断字符串是否可以解析为浮点数。"""
    try:
        float(s)
        return True
    except ValueError:
        return False


def load_csv(filepath: str | Path) -> tuple[list[str], list[list[Any]], dict[str, str]]:
    """加载 CSV 文件，返回表头、数据行和列类型映射。

    使用 csv.DictReader 读取——它自动将第一行作为表头，
    后续每一行是一个 dict（列名 → 值）。这比 csv.reader 更方便，
    因为你可以用 row["列名"] 而非 row[3] 来访问数据。

    Args:
        filepath: CSV 文件路径。

    Returns:
        (headers, rows, col_types) 三元组：
          - headers: 列名列表
          - rows: 数据行（每行是转换后的值列表）
          - col_types: 列名→类型的映射
    """
    filepath = Path(filepath)
    if not filepath.exists():
        raise FileNotFoundError(f"文件不存在: {filepath}")

    with open(filepath, "r", encoding="utf-8-sig") as f:
        # utf-8-sig 自动跳过 BOM（某些 Excel 导出的 CSV 带 BOM 头）
        reader = csv.DictReader(f)

        if reader.fieldnames is None:
            raise ValueError("CSV 文件为空或缺少表头")

        headers = list(reader.fieldnames)

        # 第一遍：收集所有行的原始字符串值
        raw_rows: list[dict[str, str]] = list(reader)

        if not raw_rows:
            return headers, [], {}

    # 检测每列的类型（按列收集所有值）
    col_types: dict[str, str] = {}
    for col in headers:
        col_values = [row.get(col, "") for row in raw_rows]
        col_types[col] = detect_type(col_values)

    # 第二遍：按检测到的类型转换值
    rows: list[list[Any]] = []
    for raw_row in raw_rows:
        converted: list[Any] = []
        for col in headers:
            value = raw_row.get(col, "").strip()
            col_type = col_types[col]

            if col_type == "int":
                converted.append(int(value) if value else 0)
            elif col_type == "float":
                converted.append(float(value) if value else 0.0)
            else:
                converted.append(value)
        rows.append(converted)

    return headers, rows, col_types


# ── 统计分析 ──────────────────────────────────────────────────────────


def compute_stats(values: list[int | float]) -> dict[str, float]:
    """计算数值列表的统计指标。

    用 Python 标准库 statistics 模块——不需要 numpy/pandas。
    这个模块是 Python 3.4 引入的，专门用于基本统计分析。

    Args:
        values: 数值列表（int 或 float）。

    Returns:
        包含 count, sum, mean, median, stdev, min, max 的字典。
    """
    if not values:
        return {"count": 0}

    return {
        "count": len(values),
        "sum": round(sum(values), 4),
        "mean": round(statistics.mean(values), 4),
        "median": round(statistics.median(values), 4),
        "stdev": round(statistics.stdev(values), 4) if len(values) >= 2 else 0.0,
        "min": round(min(values), 4),
        "max": round(max(values), 4),
    }


def compute_frequency(values: list[Any], top_n: int = 10) -> list[tuple[Any, int]]:
    """计算字符串列的值频率分布。

    使用 collections.Counter——它是专门为计数设计的 dict 子类。
    Counter 内部用 C 实现，比手写的 for 循环 + dict 快很多。

    Args:
        values: 值列表（通常是字符串）。
        top_n: 返回前 N 个最常见的值。

    Returns:
        (value, count) 的列表，按计数降序排列。
    """
    counter = Counter(values)
    return counter.most_common(top_n)


def analyze(filepath: str | Path) -> dict[str, Any]:
    """分析 CSV 文件的完整入口。

    对数值列计算统计指标，对字符串列计算频率分布。
    返回结构化的分析报告。

    Args:
        filepath: CSV 文件路径。
    """
    headers, rows, col_types = load_csv(filepath)

    if not rows:
        return {"file": str(filepath), "error": "文件为空（只有表头）"}

    report: dict[str, Any] = {
        "file": str(filepath),
        "rows": len(rows),
        "columns": len(headers),
        "column_types": col_types,
        "columns_analysis": {},
    }

    for i, col in enumerate(headers):
        col_values = [row[i] for row in rows]
        col_type = col_types[col]

        if col_type in ("int", "float"):
            report["columns_analysis"][col] = {
                "type": col_type,
                "stats": compute_stats(col_values),
                "missing": sum(1 for v in col_values if v is None or v == ""),
            }
        else:
            # 字符串列：计算缺失值 + 唯一值 + 频率
            non_empty = [v for v in col_values if v and str(v).strip()]
            report["columns_analysis"][col] = {
                "type": "str",
                "unique_count": len(set(str(v) for v in col_values)),
                "missing": len(col_values) - len(non_empty),
                "top_values": compute_frequency(
                    [str(v) for v in col_values if v], top_n=5
                ),
            }

    return report


# ── 格式化输出 ────────────────────────────────────────────────────────


def print_report(report: dict[str, Any]) -> None:
    """将分析报告打印为可读的文本格式。"""
    print("=" * 60)
    print(f"📊 CSV 分析报告: {report['file']}")
    print("=" * 60)
    print(f"  行数: {report['rows']}")
    print(f"  列数: {report['columns']}")
    print()

    for col, analysis in report.get("columns_analysis", {}).items():
        print(f"  📌 {col} ({analysis['type']})")
        if "stats" in analysis:
            stats = analysis["stats"]
            print(f"     数量: {stats['count']}, 均值: {stats['mean']}")
            print(f"     中位数: {stats['median']}, 标准差: {stats['stdev']}")
            print(f"     范围: [{stats['min']}, {stats['max']}]")
            if analysis.get("missing"):
                print(f"     ⚠️  缺失值: {analysis['missing']}")
        else:
            print(f"     唯一值: {analysis['unique_count']}")
            if analysis.get("missing"):
                print(f"     ⚠️  缺失值: {analysis['missing']}")
            if analysis.get("top_values"):
                print(f"     频率 Top 5: {analysis['top_values']}")
        print()


# ── 使用示例 ─────────────────────────────────────────────────────────


if __name__ == "__main__":
    # 1. 创建一个示例 CSV 文件
    sample_csv = Path("sample_data.csv")
    sample_csv.write_text(
        "name,age,score,city\n"
        "Alice,25,88.5,Beijing\n"
        "Bob,30,92.0,Shanghai\n"
        "Charlie,22,76.5,Beijing\n"
        "Diana,28,95.0,Guangzhou\n"
        "Eve,35,89.0,Shanghai\n"
        "Frank,27,67.5,Beijing\n"
        "Grace,31,82.0,Shenzhen\n"
        "Henry,24,91.5,Shanghai\n",
        encoding="utf-8",
    )

    # 2. 分析
    result = analyze(sample_csv)
    print_report(result)

    # 3. 清理
    sample_csv.unlink()
    print("✅ 示例文件已清理")
