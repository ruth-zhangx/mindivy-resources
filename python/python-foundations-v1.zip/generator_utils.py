#!/usr/bin/env python3
"""Generator Utils — 生成器与 itertools 实战

生成器 (generator) 是 Python 处理大数据和流式数据的基础。
与返回列表不同，生成器「惰性求值」——只在需要时才产生下一个值，
这意味着你可以处理无法放入内存的无限序列。

核心概念：
  - 生成器函数：用 yield 代替 return
  - 生成器表达式：(x for x in ...) —— 列表推导式的惰性版本
  - itertools：Python 标准库的生成器工具箱

学习路径：
  1. fibonacci — 理解 yield 的基本用法
  2. chunked — 实战：分批处理大数据
  3. sliding_window — 实战：滑动窗口
  4. itertools 精选 — 6 个最常用的 itertools 工具
"""

import itertools
from typing import Iterator, TypeVar

T = TypeVar("T")


# ── 1. 基础：无限斐波那契数列 ───────────────────────────────────────

def fibonacci() -> Iterator[int]:
    """生成无限的斐波那契数列。

    yield 和 return 的关键区别：
      - return: 函数结束，返回一个值
      - yield:  函数暂停，产出一个值；下次调用 next() 时从暂停处继续

    因为这是无限的，调用时一定要配合切片或条件终止：
      for n in fibonacci():
          if n > 1000:
              break
          print(n)
    """
    a, b = 0, 1
    while True:
        yield a
        a, b = b, a + b  # 并行赋值——Python 的优雅特性


# ── 2. 实战：分批处理 ───────────────────────────────────────────────

def chunked(iterable: list[T], size: int) -> Iterator[list[T]]:
    """将可迭代对象切分为固定大小的批次。

    这是批量处理数据的标准模式——比如每 100 条记录写一次数据库，
    而不是全部加载到内存再处理。

    Args:
        iterable: 要切分的数据。
        size: 每批的大小。

    Yields:
        大小为 size 的批次（最后一批可能更小）。

    Usage:
        for batch in chunked(huge_list, 100):
            process_batch(batch)
    """
    for i in range(0, len(iterable), size):
        yield iterable[i:i + size]


# ── 3. 实战：滑动窗口 ───────────────────────────────────────────────

def sliding_window(iterable: list[T], n: int) -> Iterator[tuple[T, ...]]:
    """生成滑动窗口——用于时间序列分析、N-gram 等。

    示例：sliding_window([1,2,3,4,5], 3) → (1,2,3), (2,3,4), (3,4,5)

    Args:
        iterable: 输入序列。
        n: 窗口大小。

    Yields:
        长度为 n 的滑动窗口元组。

    Usage:
        for a, b, c in sliding_window(prices, 3):
            if a < b > c:  # 检测局部峰值
                print(f"Peak at: {b}")
    """
    if n > len(iterable):
        return
    for i in range(len(iterable) - n + 1):
        yield tuple(iterable[i:i + n])


# ── 4. itertools 精选 ───────────────────────────────────────────────

def itertools_showcase():
    """展示 6 个最常用的 itertools 工具。

    itertools 是 Python 标准库中处理迭代器的模块——
    它提供了一组高性能、内存友好的迭代器构建块。
    """

    # 1. islice — 惰性切片（不创建新列表）
    print("islice: 取斐波那契数列的前 10 项")
    first_10 = itertools.islice(fibonacci(), 10)
    print(f"  {list(first_10)}")

    # 2. chain — 串联多个可迭代对象
    print("\nchain: 合并三个列表")
    merged = itertools.chain([1, 2], [3, 4], [5, 6])
    print(f"  {list(merged)}")

    # 3. groupby — 按 key 分组（数据必须预先排序！）
    print("\ngroupby: 按首字母分组")
    words = sorted(["apple", "ant", "banana", "bird", "cat"])
    for key, group in itertools.groupby(words, key=lambda w: w[0]):
        print(f"  {key}: {list(group)}")

    # 4. product — 笛卡尔积
    print("\nproduct: 所有可能的骰子组合")
    dice = itertools.product(range(1, 7), repeat=2)
    print(f"  总共 {6*6} 种组合")

    # 5. combinations — 无放回组合
    print("\ncombinations: 从 4 人中选 2 人组队")
    teams = itertools.combinations(["Alice", "Bob", "Carol", "Dave"], 2)
    for team in teams:
        print(f"  {team[0]} & {team[1]}")

    # 6. accumulate — 累积（默认是累加，可以换成任何二元函数）
    print("\naccumulate: 累积和 + 累积乘积")
    import operator
    nums = [1, 2, 3, 4, 5]
    print(f"  累积和: {list(itertools.accumulate(nums))}")
    print(f"  累积乘积: {list(itertools.accumulate(nums, operator.mul))}")


# ── 生成器表达式 vs 列表推导式 ──────────────────────────────────────

def memory_comparison():
    """演示生成器表达式节省内存。

    生成器表达式用 () 而非 []——语法几乎一样，
    但不会一次性创建整个列表。
    """
    import sys

    # 列表推导式：一次性创建 1000 万个 int → ~80 MB
    # list_comp = [x * 2 for x in range(10_000_000)]  # 不要运行！

    # 生成器表达式：只是「如何生成」的配方 → ~200 bytes
    gen_expr = (x * 2 for x in range(10_000_000))
    print(f"生成器表达式占用内存: {sys.getsizeof(gen_expr)} bytes")
    print(f"前 5 个值: {list(itertools.islice(gen_expr, 5))}")


# ── 使用示例 ────────────────────────────────────────────────────────

if __name__ == "__main__":
    print("=" * 40)
    print("斐波那契数列前 10 项:")
    for i, n in enumerate(fibonacci()):
        if i >= 10:
            break
        print(f"  F({i}) = {n}")

    print("\n" + "=" * 40)
    print("分批处理: [0..9] 按 3 个一组")
    for batch in chunked(list(range(10)), 3):
        print(f"  {batch}")

    print("\n" + "=" * 40)
    print("滑动窗口: [1..6] 窗口大小 3")
    for window in sliding_window([1, 2, 3, 4, 5, 6], 3):
        print(f"  {window}")

    print("\n" + "=" * 40)
    itertools_showcase()

    print("\n" + "=" * 40)
    memory_comparison()
