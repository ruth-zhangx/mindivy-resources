#!/usr/bin/env python3
"""Decorator Library — 装饰器工具箱

装饰器 (decorator) 是 Python 最强大的特性之一：它让你在不修改原函数
代码的情况下，给函数添加额外的行为。本文件展示了 5 种实用装饰器。

核心概念：
  装饰器本质上是一个「接收函数、返回函数」的高阶函数。
  @decorator 语法等价于 `func = decorator(func)`。

学习路径：
  1. timer — 最简单的装饰器，理解基本结构
  2. retry — 带参数的装饰器（需要三层嵌套！）
  3. cache — functools.lru_cache 的使用
  4. require_auth — 用装饰器做权限检查
  5. log_calls — 类装饰器 vs 函数装饰器
"""

import functools
import time
import logging
from typing import Callable, Any

logger = logging.getLogger(__name__)


# ── 1. timer — 测量函数执行时间 ─────────────────────────────────────

def timer(func: Callable) -> Callable:
    """测量并打印函数的执行时间。

    这是最基础的装饰器模式：
      - 接收一个函数 func
      - 返回一个新函数 wrapper
      - wrapper 在执行 func 前后记录时间

    Args:
        func: 被装饰的函数。

    Usage:
        @timer
        def slow_function():
            time.sleep(1)
    """
    @functools.wraps(func)  # 保留原函数的 __name__ 和 __doc__
    def wrapper(*args, **kwargs) -> Any:
        start = time.perf_counter()
        result = func(*args, **kwargs)
        elapsed = time.perf_counter() - start
        logger.info(f"{func.__name__} took {elapsed:.4f}s")
        return result
    return wrapper


# ── 2. retry — 失败自动重试 ─────────────────────────────────────────

def retry(max_attempts: int = 3, delay: float = 1.0):
    """失败时自动重试的装饰器（带参数版本）。

    这是「带参数的装饰器」——比 timer 多一层嵌套：
      - 第一层接收装饰器参数 (max_attempts, delay)
      - 第二层接收被装饰的函数 (func)
      - 第三层是实际的 wrapper

    为什么需要三层？
      因为 @retry(max_attempts=5) 是一个函数调用——
      它返回「真正的装饰器」，然后真正的装饰器再接收 func。

    Args:
        max_attempts: 最大重试次数。
        delay: 每次重试之间的等待秒数。

    Usage:
        @retry(max_attempts=5, delay=2.0)
        def flaky_api_call():
            ...
    """
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> Any:
            last_error = None
            for attempt in range(1, max_attempts + 1):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    last_error = e
                    if attempt < max_attempts:
                        logger.warning(
                            f"{func.__name__} attempt {attempt}/{max_attempts} "
                            f"failed: {e}. Retrying in {delay}s..."
                        )
                        time.sleep(delay)
            # 所有重试都失败——抛出最后一个异常
            raise last_error  # type: ignore[misc]
        return wrapper
    return decorator


# ── 3. memoize — 函数结果缓存 ───────────────────────────────────────

def memoize(func: Callable) -> Callable:
    """缓存函数调用结果——相同输入直接返回缓存值。

    这模仿了 functools.lru_cache 的核心行为，帮助理解它的原理：
      - 用字典存储 (args, kwargs) → result 的映射
      - 注意：kwargs 必须是可哈希的（不能用 list/dict 做参数）

    生产环境请用 @functools.lru_cache(maxsize=128) 代替——
    它有大小限制、线程安全、统计信息等完整功能。

    Args:
        func: 被装饰的函数（参数必须可哈希）。

    Usage:
        @memoize
        def fibonacci(n):
            if n < 2: return n
            return fibonacci(n-1) + fibonacci(n-2)
    """
    cache: dict = {}

    @functools.wraps(func)
    def wrapper(*args, **kwargs) -> Any:
        # 将 kwargs 转为可哈希的 tuple（sorted 保证顺序一致）
        key = (args, tuple(sorted(kwargs.items())))
        if key not in cache:
            cache[key] = func(*args, **kwargs)
        return cache[key]

    # 暴露缓存以便外部检查和清理
    wrapper.cache = cache  # type: ignore[attr-defined]
    return wrapper


# ── 4. require_auth — 权限检查装饰器 ────────────────────────────────

# 模拟当前登录用户（实际项目中从 session/request 获取）
_current_user: str | None = None


def login(username: str) -> None:
    """设置当前用户（模拟登录）。"""
    global _current_user
    _current_user = username


def logout() -> None:
    """清除当前用户（模拟登出）。"""
    global _current_user
    _current_user = None


def require_auth(func: Callable) -> Callable:
    """检查用户是否已登录——未登录则抛出异常。

    这是「前置条件检查」装饰器的典型模式：
      - 在执行函数前检查条件
      - 不满足时抛出异常（而非默默返回 None）
      - 这样调用方必须处理权限问题

    Usage:
        @require_auth
        def delete_account():
            ...
    """
    @functools.wraps(func)
    def wrapper(*args, **kwargs) -> Any:
        if _current_user is None:
            raise PermissionError("请先登录再执行此操作")
        return func(*args, **kwargs)
    return wrapper


# ── 5. log_calls — 类装饰器 ─────────────────────────────────────────

class log_calls:
    """用类实现的装饰器——记录每次函数调用。

    为什么用类而不是函数？
      - 可以保持状态（call_count）
      - 可以添加方法（如 reset()）
      - 更适合复杂的装饰逻辑

    类的 __call__ 方法让实例可以像函数一样被调用——
    这是 Python 的「可调用对象」协议。

    Usage:
        @log_calls
        def greet(name):
            return f"Hello, {name}!"
    """

    def __init__(self, func: Callable):
        functools.update_wrapper(self, func)
        self.func = func
        self.call_count = 0

    def __call__(self, *args, **kwargs) -> Any:
        self.call_count += 1
        logger.info(
            f"{self.func.__name__} called (#{self.call_count}) "
            f"with args={args}, kwargs={kwargs}"
        )
        return self.func(*args, **kwargs)

    def reset(self) -> None:
        """重置调用计数。"""
        self.call_count = 0


# ── 使用示例 ────────────────────────────────────────────────────────

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)

    @timer
    @memoize
    def fibonacci(n: int) -> int:
        """计算第 n 个斐波那契数（递归，未优化）。"""
        if n < 2:
            return n
        return fibonacci(n - 1) + fibonacci(n - 2)

    # 没有 memoize 的话，fibonacci(35) 需要 ~5 秒
    # 有了 memoize，每个 n 只计算一次——接近即时的结果
    print(f"fibonacci(35) = {fibonacci(35)}")
    print(f"缓存条目数: {len(fibonacci.cache)}")

    @log_calls
    def greet(name: str) -> str:
        return f"Hello, {name}!"

    greet("Ruth")
    greet("Claude")
    print(f"greet 被调用了 {greet.call_count} 次")
