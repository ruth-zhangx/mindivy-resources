#!/usr/bin/env python3
"""Context Managers — 上下文管理器三种实现方式

上下文管理器 (context manager) 让你优雅地管理资源——确保无论发生什么，
资源都会被正确释放。`with` 语句是 Python 最常用的资源管理模式。

核心概念：
  with obj as x:  等价于：
    1. x = obj.__enter__()   — 获取资源
    2. 执行 with 块中的代码
    3. obj.__exit__(...)     — 释放资源（即使有异常也会执行！）

学习路径：
  1. FileManager — 类实现，理解 __enter__/__exit__ 协议
  2. timer — contextlib.contextmanager 装饰器实现
  3. working_dir — 临时切换工作目录再切回
"""

import os
import time
from contextlib import contextmanager
from typing import Iterator


# ── 方式一：类实现（最直观） ─────────────────────────────────────────

class FileManager:
    """安全的文件操作——自动关闭文件，即使发生异常。

    这是上下文管理器协议的完整实现：
      - __enter__: 打开文件，返回文件对象
      - __exit__:  关闭文件（exc_type 非 None 表示有异常）

    对比传统方式：
      f = open("file.txt")    # 如果后面的代码抛异常，f.close() 不会执行
      try:
          data = f.read()
      finally:
          f.close()

      with FileManager("file.txt") as f:  # 无论如何都会关闭
          data = f.read()

    Args:
        filepath: 文件路径。
        mode: 打开模式（'r', 'w', 'a' 等）。
    """

    def __init__(self, filepath: str, mode: str = "r"):
        self.filepath = filepath
        self.mode = mode
        self.file = None

    def __enter__(self):
        """进入 with 块——打开文件并返回文件对象。"""
        print(f"📂 打开文件: {self.filepath}")
        self.file = open(self.filepath, self.mode)
        return self.file

    def __exit__(self, exc_type, exc_val, exc_tb):
        """退出 with 块——无论如何都会执行。

        Args:
            exc_type: 异常类型（没有异常时为 None）
            exc_val:  异常值
            exc_tb:   traceback

        Returns:
            False 让异常继续传播，True 会吞掉异常（一般不推荐）
        """
        if self.file:
            self.file.close()
            print(f"📂 关闭文件: {self.filepath}")
        if exc_type:
            print(f"⚠️  在 with 块内发生了异常: {exc_type.__name__}: {exc_val}")
        return False  # 不吞异常


# ── 方式二：contextlib.contextmanager（最简洁） ─────────────────────

@contextmanager
def timer(description: str = "操作") -> Iterator[None]:
    """测量代码块的执行时间——用 contextmanager 装饰器实现。

    @contextmanager 把一个生成器函数变成上下文管理器：
      - yield 之前的代码 = __enter__
      - yield 之后的代码 = __exit__（即使有异常也会执行）

    这是最常用的方式——比类实现少很多样板代码。

    Usage:
        with timer("数据库查询"):
            results = db.query(...)
    """
    start = time.perf_counter()
    try:
        yield  # 在这里执行 with 块中的代码
    finally:
        elapsed = time.perf_counter() - start
        print(f"⏱️  {description}: {elapsed:.4f}s")


# ── 方式三：组合以上两种 ────────────────────────────────────────────

@contextmanager
def working_dir(path: str) -> Iterator[None]:
    """临时切换到指定目录，执行完后自动切回原目录。

    这个模式在处理文件系统操作时非常有用——你不必记住「切回去」，
    with 块自动保证了这一点。这比 try/finally 优雅得多：

      old = os.getcwd()
      try:
          os.chdir(path)
          ...  # do work
      finally:
          os.chdir(old)

      # vs

      with working_dir(path):
          ...  # do work

    Args:
        path: 要切换到的目标目录。

    Usage:
        with working_dir("/tmp"):
            # 在 /tmp 下工作
            ...
        # 自动回到原来的目录
    """
    old_dir = os.getcwd()
    os.chdir(path)
    try:
        yield
    finally:
        os.chdir(old_dir)


# ── 实战：嵌套上下文管理器 ──────────────────────────────────────────

class DatabaseConnection:
    """模拟数据库连接——演示嵌套上下文管理。

    实际项目中，数据库连接池通常有以下层次：
      Database → Transaction → Cursor
    每一层都是一个上下文管理器，with 可以嵌套：
      with Database(...) as db:
          with db.transaction():
              with db.cursor() as cur:
                  cur.execute(...)
    """

    def __init__(self, dsn: str):
        self.dsn = dsn
        self._connected = False

    def __enter__(self):
        print(f"🔌 连接数据库: {self.dsn}")
        self._connected = True
        return self

    def __exit__(self, *args):
        self._connected = False
        print(f"🔌 断开连接: {self.dsn}")
        return False

    def transaction(self):
        """开始一个事务——返回事务上下文管理器。"""
        return _Transaction(self)


class _Transaction:
    """数据库事务上下文管理器（内部类——外部不应直接使用）。"""

    def __init__(self, db: DatabaseConnection):
        self.db = db

    def __enter__(self):
        print("  💾 BEGIN TRANSACTION")
        return self

    def __exit__(self, exc_type, *args):
        if exc_type:
            print("  💾 ROLLBACK")
        else:
            print("  💾 COMMIT")
        return False  # 不吞异常


# ── 使用示例 ────────────────────────────────────────────────────────

if __name__ == "__main__":
    # 方式一：类实现
    print("=" * 40)
    print("方式一：FileManager")
    with FileManager("/tmp/test.txt", "w") as f:
        f.write("Hello, Context Manager!")

    # 方式二：contextmanager 装饰器
    print("\n" + "=" * 40)
    print("方式二：@contextmanager")
    with timer("斐波那契计算"):
        # 计算一个较大的斐波那契数
        a, b = 0, 1
        for _ in range(100_000):
            a, b = b, a + b

    # 方式三：嵌套
    print("\n" + "=" * 40)
    print("方式三：嵌套上下文管理器")
    with DatabaseConnection("postgresql://localhost/mydb") as db:
        with db.transaction():
            print("    📝 执行 SQL...")
    print("所有资源已正确释放 ✅")
