#!/usr/bin/env python3
"""URL Shortener — 短链接服务

使用 Python 内置库构建一个简单的短链接服务，涵盖以下核心概念：
  - 字典 (dict) 的映射与查找
  - 哈希 (hash) 的基本原理与短码生成
  - HTTP 服务器 (http.server) 的请求处理
  - Base URL 重定向

学习路径：
  1. short_to_url dict — 核心数据结构的选型
  2. generate_short_code() — 哈希与短码
  3. URLShortenerHandler — HTTP 请求处理
  4. 运行服务并测试重定向
"""

import hashlib
import json
import os
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs

# ── 数据层：短码 ↔ URL 映射 ──────────────────────────────────────────

# 用 dict 存储映射关系——O(1) 查找，简单直接
# key: 短码 (str), value: 原始 URL (str)
short_to_url: dict[str, str] = {}
url_to_short: dict[str, str] = {}  # 反向映射：避免重复短链


def generate_short_code(url: str, length: int = 7) -> str:
    """为 URL 生成唯一的短码。

    使用 SHA-256 哈希的前 length 个字符作为短码。
    SHA-256 保证：
      - 确定性：相同 URL 总是生成相同短码
      - 均匀分布：不同 URL 极大概率不同短码
      - 不可逆：无法从短码反推原始 URL

    注意：length=7 提供 16^7 ≈ 2.68 亿种可能，对于学习项目足够。
    生产环境建议用 base62 (A-Za-z0-9) 编码以支持更多短码。

    Args:
        url: 原始 URL。
        length: 短码长度（默认 7 个十六进制字符）。

    Returns:
        短码字符串。
    """
    hash_hex = hashlib.sha256(url.encode()).hexdigest()
    return hash_hex[:length]


def shorten(url: str, base_url: str = "http://localhost:8000") -> str:
    """将 URL 转换为短链接。

    如果该 URL 已有短码则复用（去重），否则生成新短码。

    Args:
        url: 需要缩短的原始 URL。
        base_url: 短链接的基础 URL。

    Returns:
        完整的短链接字符串，如 "http://localhost:8000/a1b2c3d"。
    """
    # 去重检查：同一 URL 不重复创建短码
    if url in url_to_short:
        short_code = url_to_short[url]
    else:
        short_code = generate_short_code(url)
        # 哈希冲突处理：如果短码已被另一个 URL 使用，加长重试
        while short_code in short_to_url and short_to_url[short_code] != url:
            short_code = generate_short_code(url + short_code)  # 加盐重新哈希
        short_to_url[short_code] = url
        url_to_short[url] = short_code

    return f"{base_url}/{short_code}"


def expand(short_code: str) -> str | None:
    """根据短码查找原始 URL。

    Args:
        short_code: 短码（不含路径前缀）。

    Returns:
        原始 URL，如果短码不存在则返回 None。
    """
    return short_to_url.get(short_code)
    # dict.get(key) 是安全的查找方式——
    # key 不存在时返回 None（或指定默认值），不会抛出 KeyError


# ── HTTP 服务器：处理短链接请求 ──────────────────────────────────────


class URLShortenerHandler(BaseHTTPRequestHandler):
    """处理短链接的 HTTP 请求处理器。

    继承自 BaseHTTPRequestHandler——Python 标准库自带的 HTTP 服务器基类。
    只需覆盖 do_GET() 和 do_POST() 方法即可自定义行为。

    路由规则：
      GET  /{short_code} → 302 重定向到原始 URL
      POST /             → 创建短链接（JSON body: {"url": "..."}）
      GET  /             → 返回 API 使用说明
    """

    def do_GET(self):
        """处理 GET 请求：短链接重定向或首页。

        解析请求路径——如果是短码则重定向，否则返回首页说明。
        urlparse 将 URL 分解为协议、主机、路径、查询参数等组件。
        """
        parsed = urlparse(self.path)
        short_code = parsed.path.lstrip("/")  # 去掉前导斜杠

        if short_code:
            # 尝试作为短码处理
            original_url = expand(short_code)
            if original_url:
                # 302 Found：临时重定向
                # 生产环境常用 301 Moved Permanently（永久重定向），
                # 但 302 更灵活——短码映射随时可变
                self.send_response(302)
                self.send_header("Location", original_url)
                self.end_headers()
                return

            # 短码不存在
            self.send_response(404)
            self.send_header("Content-type", "application/json")
            self.end_headers()
            error_msg = json.dumps({"error": f"Short code '{short_code}' not found"})
            self.wfile.write(error_msg.encode())
            return

        # 首页：返回 API 使用说明
        self.send_response(200)
        self.send_header("Content-type", "text/html; charset=utf-8")
        self.end_headers()
        html = """
        <h1>🔗 URL Shortener</h1>
        <p>POST <code>/</code> with JSON <code>{"url": "https://example.com"}</code> to shorten.</p>
        <p>GET <code>/{short_code}</code> to visit the original URL.</p>
        """
        self.wfile.write(html.encode())

    def do_POST(self):
        """处理 POST 请求：创建短链接。

        读取请求体 JSON，提取 url 字段，返回短链接。

        注意：BaseHTTPRequestHandler 不会自动解析 JSON——
        需要手动读取 Content-Length 并 json.loads()。
        """
        # 读取请求体
        content_length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(content_length).decode()

        try:
            data = json.loads(body)
            url = data.get("url", "")
        except json.JSONDecodeError:
            self.send_response(400)
            self.send_header("Content-type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps({"error": "Invalid JSON"}).encode())
            return

        if not url:
            self.send_response(400)
            self.send_header("Content-type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps({"error": "Missing 'url' field"}).encode())
            return

        short_url = shorten(url)
        short_code = short_url.rsplit("/", 1)[-1]

        self.send_response(201)  # 201 Created
        self.send_header("Content-type", "application/json")
        self.end_headers()
        response = json.dumps({
            "short_url": short_url,
            "short_code": short_code,
            "original_url": url,
        })
        self.wfile.write(response.encode())

    def log_message(self, format, *args):
        """自定义日志格式——比默认的更简洁。"""
        print(f"[{self.command}] {args[0]}")


# ── 服务启动 ─────────────────────────────────────────────────────────


def run_server(host: str = "localhost", port: int = 8000):
    """启动 URL Shortener 服务。

    HTTPServer 是 Python 标准库的同步 HTTP 服务器——
    一次只处理一个请求，适合开发和轻量使用。
    生产环境请用 gunicorn 或 uvicorn。
    """
    server = HTTPServer((host, port), URLShortenerHandler)
    print(f"🔗 URL Shortener running at http://{host}:{port}")
    print(f"   示例：curl -X POST http://{host}:{port}/ -d '{{\"url\": \"https://python.org\"}}'")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n👋 服务已停止")
        server.server_close()


# ── 使用示例 ─────────────────────────────────────────────────────────

if __name__ == "__main__":
    # 命令行演示（不启动完整服务器）
    print("=" * 50)
    print("URL Shortener — 演示")
    print("=" * 50)

    # 创建几个短链接
    urls = [
        "https://docs.python.org/3/library/hashlib.html",
        "https://docs.python.org/3/library/http.server.html",
        "https://docs.python.org/3/tutorial/datastructures.html#dictionaries",
    ]
    for url in urls:
        short = shorten(url)
        print(f"  {short}")
        print(f"    → {url}")

    print(f"\n📊 统计: {len(short_to_url)} 个短链接已生成")
    print(f"   短码空间使用率: {len(short_to_url)} / 16^7 ≈ {len(short_to_url) / 16**7:.10f}")

    # 验证去重
    print("\n🔄 去重测试: 重复缩短同一个 URL...")
    same = shorten(urls[0])
    print(f"  第一次: {same}")
    print(f"  第二次: {shorten(urls[0])} ← 相同（去重生效）")

    # 验证查找
    print("\n🔍 查找测试:")
    code = list(short_to_url.keys())[0]
    print(f"  短码: {code}")
    print(f"  原始 URL: {expand(code)}")

    # 启动服务器（按 Ctrl+C 停止）
    print("\n🚀 启动 HTTP 服务器...")
    run_server()
