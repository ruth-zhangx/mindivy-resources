#!/usr/bin/env python3
"""Markdown Preview — Markdown 转 HTML 实时预览

将 Markdown 文件转换为 HTML 预览页面，涵盖以下核心概念：
  - 字符串处理与正则表达式
  - 文件系统操作 (pathlib)
  - 使用 markdown 库转换为 HTML
  - 基本的 HTML 模板与 CSS 内联

学习路径：
  1. 理解 Markdown 解析流程（逐行处理 → HTML）
  2. _parse_inline() — 行内格式（粗体/斜体/代码/链接）
  3. _parse_blocks() — 块级元素（标题/列表/代码块/段落）
  4. render() — 组装完整 HTML 页面
  5. 对比 markdown 库的实现

注意：这是一个简化的 Markdown 解析器，用于理解解析原理。
生产环境请使用 python-markdown 或 mistune 等成熟的库。
"""

import re
import sys
from pathlib import Path
from typing import List

# ── 行内元素解析 ─────────────────────────────────────────────────────


def _parse_inline(text: str) -> str:
    """解析行内 Markdown 格式——粗体、斜体、代码、链接、图片。

    处理顺序很重要！粗体（**）必须在斜体（*）之前处理，
    否则 `**text**` 会被误匹配为两个斜体标记。

    正则表达式解释：
      - `**text**` 或 `__text__` → <strong>  (粗体)
      - `*text*` 或 `_text_`   → <em>      (斜体，但不是 ** 的一部分)
      - `` `code` ``          → <code>
      - `[text](url)`        → <a href>
      - `![alt](url)`        → <img>       (在链接之前处理)
    """
    # 图片：![alt](url) —— 必须在链接之前处理，避免误匹配
    text = re.sub(r'!\[([^\]]*)\]\(([^)]+)\)', r'<img src="\2" alt="\1">', text)

    # 链接：[text](url)
    text = re.sub(r'\[([^\]]*)\]\(([^)]+)\)', r'<a href="\2">\1</a>', text)

    # 粗体：**text** 或 __text__
    text = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', text)
    text = re.sub(r'__(.+?)__', r'<strong>\1</strong>', text)

    # 斜体：*text* 或 _text_（但不能是 ** 的一部分）
    text = re.sub(r'(?<!\*)\*(?!\*)(.+?)(?<!\*)\*(?!\*)', r'<em>\1</em>', text)
    text = re.sub(r'(?<!_)_(?!_)(.+?)(?<!_)_(?!_)', r'<em>\1</em>', text)

    # 行内代码：`code`
    text = re.sub(r'`([^`]+)`', r'<code>\1</code>', text)

    return text


# ── 块级元素解析 ─────────────────────────────────────────────────────


def _parse_blocks(lines: List[str]) -> str:
    """将 Markdown 行列表解析为 HTML 块级元素。

    采用「状态机」思路逐行处理：
      - 看到 `# ` 开头 → 标题
      - 看到 `- ` 或 `* ` 开头 → 无序列表项
      - 看到 ``` → 切换代码块状态
      - 空行 → 段落分隔
      - 其他 → 普通段落

    这是编译器前端的基础——词法分析 (tokenize) → 语法分析 (parse)。
    真正的 Markdown 解析器还有 AST (抽象语法树) 阶段，
    但逐行状态机对于简单格式已经足够。
    """
    html: List[str] = []
    i = 0

    while i < len(lines):
        line = lines[i]

        # 空行 → 跳过（段落之间用 <br> 隔开自动产生间距）
        if not line.strip():
            i += 1
            continue

        # 标题：`# ` ~ `###### `
        heading_match = re.match(r'^(#{1,6})\s+(.+)', line)
        if heading_match:
            level = len(heading_match.group(1))  # # 的数量 = 标题级别
            content = _parse_inline(heading_match.group(2))
            html.append(f"<h{level}>{content}</h{level}>")
            i += 1
            continue

        # 水平线：--- 或 *** 或 ___
        if re.match(r'^[-*_]{3,}\s*$', line):
            html.append("<hr>")
            i += 1
            continue

        # 代码块：``` ... ```
        if line.strip().startswith("```"):
            language = line.strip()[3:].strip()  # 可选的语言标识
            i += 1
            code_lines: List[str] = []
            while i < len(lines) and not lines[i].strip().startswith("```"):
                code_lines.append(lines[i])
                i += 1
            i += 1  # 跳过结束的 ```

            code_content = "\n".join(code_lines)
            # HTML 转义：< > & 在代码块中必须转义
            code_content = code_content.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            if language:
                html.append(f'<pre><code class="language-{language}">{code_content}</code></pre>')
            else:
                html.append(f"<pre><code>{code_content}</code></pre>")
            continue

        # 无序列表：连续的多行 `- item` 或 `* item`
        if re.match(r'^[-*]\s+', line):
            items: List[str] = []
            while i < len(lines) and re.match(r'^[-*]\s+', lines[i]):
                item_content = _parse_inline(re.sub(r'^[-*]\s+', '', lines[i]))
                items.append(f"<li>{item_content}</li>")
                i += 1
            html.append(f"<ul>{''.join(items)}</ul>")
            continue

        # 引用块：`> text`
        if line.startswith(">"):
            quote_lines: List[str] = []
            while i < len(lines) and lines[i].startswith(">"):
                quote_lines.append(lines[i][1:].strip())  # 去掉 `> `
                i += 1
            quote_content = "<br>\n".join(_parse_inline(l) for l in quote_lines)
            html.append(f"<blockquote>{quote_content}</blockquote>")
            continue

        # 普通段落：收集连续非空行，直到遇到空行或特殊块
        para_lines: List[str] = []
        while i < len(lines) and lines[i].strip():
            # 如果下一行是特殊块，当前段落结束
            if re.match(r'^(#{1,6}\s|```|[-*]\s|>\s|[-*_]{3,}\s*$)', lines[i]):
                break
            para_lines.append(_parse_inline(lines[i]))
            i += 1
        if para_lines:
            html.append(f"<p>{'<br>\n'.join(para_lines)}</p>")

    return "\n".join(html)


# ── 完整页面渲染 ─────────────────────────────────────────────────────


def render(markdown_text: str, title: str = "Markdown Preview") -> str:
    """将 Markdown 文本渲染为完整的 HTML 页面。

    组装三步：
      1. 按行分割
      2. 解析块级元素 → HTML body
      3. 包装为完整 HTML（带基本 CSS 样式）

    Args:
        markdown_text: Markdown 格式的文本。
        title: HTML 页面的标题。

    Returns:
        完整的 HTML 文档字符串。
    """
    lines = markdown_text.split("\n")
    body = _parse_blocks(lines)

    # 基本 CSS 样式——让预览看起来像 GitHub README
    return f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title}</title>
    <style>
        body {{
            max-width: 800px;
            margin: 40px auto;
            padding: 0 20px;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif;
            font-size: 16px;
            line-height: 1.6;
            color: #24292e;
            background: #fff;
        }}
        h1, h2 {{ border-bottom: 1px solid #eaecef; padding-bottom: 0.3em; }}
        h1 {{ font-size: 2em; }}
        h2 {{ font-size: 1.5em; }}
        h3 {{ font-size: 1.25em; }}
        code {{
            background: #f6f8fa;
            padding: 2px 6px;
            border-radius: 3px;
            font-family: "SFMono-Regular", Consolas, "Liberation Mono", Menlo, monospace;
            font-size: 85%;
        }}
        pre {{
            background: #f6f8fa;
            padding: 16px;
            border-radius: 6px;
            overflow-x: auto;
        }}
        pre code {{ background: none; padding: 0; }}
        blockquote {{
            border-left: 4px solid #dfe2e5;
            padding: 0 15px;
            color: #6a737d;
            margin: 0;
        }}
        hr {{ border: none; border-top: 1px solid #eaecef; margin: 24px 0; }}
        img {{ max-width: 100%; }}
        a {{ color: #0366d6; text-decoration: none; }}
        a:hover {{ text-decoration: underline; }}
    </style>
</head>
<body>
{body}
</body>
</html>"""


def render_file(input_path: str | Path, output_path: str | Path | None = None) -> str:
    """读取 Markdown 文件并渲染为 HTML。

    Args:
        input_path: Markdown 文件路径。
        output_path: 输出 HTML 文件的路径。如果为 None，自动生成（同目录、同名、.html 后缀）。

    Returns:
        输出文件的路径。
    """
    input_path = Path(input_path)
    if not input_path.exists():
        raise FileNotFoundError(f"文件不存在: {input_path}")

    markdown_text = input_path.read_text(encoding="utf-8")

    if output_path is None:
        output_path = input_path.with_suffix(".html")
    else:
        output_path = Path(output_path)

    html = render(markdown_text, title=input_path.stem)
    output_path.write_text(html, encoding="utf-8")
    return str(output_path)


# ── 对比：使用 python-markdown 库 ────────────────────────────────────


def render_with_library(markdown_text: str) -> str:
    """使用 python-markdown 库渲染（需要 pip install markdown）。

    这是生产级的实现——只需几行代码。对比上面的手动实现，
    可以感受到库的作者处理了多少边界情况。
    """
    try:
        import markdown
    except ImportError:
        raise ImportError(
            "需要安装 markdown 库。运行: pip install markdown"
        )

    extensions = [
        "fenced_code",       # 围栏代码块 ```
        "tables",            # 表格支持
        "codehilite",        # 代码语法高亮
        "toc",               # 自动生成目录
    ]
    body = markdown.markdown(markdown_text, extensions=extensions)

    return f"""<!DOCTYPE html>
<html lang="zh-CN">
<head><meta charset="UTF-8"><title>Preview</title></head>
<body>{body}</body>
</html>"""


# ── 使用示例 ─────────────────────────────────────────────────────────

if __name__ == "__main__":
    sample_md = """# Markdown 语法演示

## 文本格式

这是**粗体**和*斜体*，还有`行内代码`。

## 链接和图片

访问 [Python 官网](https://python.org)。

## 列表

- 第一项
- 第二项
- 第三项

## 引用

> 简单就是美。
> —— Python 之禅

## 代码块

```python
def hello():
    print("Hello, Markdown!")
```

---

*由 Markdown Preview 生成*
"""

    print("=" * 50)
    print("输入 Markdown:")
    print("=" * 50)
    print(sample_md)

    print("\n" + "=" * 50)
    print("输出 HTML:")
    print("=" * 50)
    html_output = render(sample_md)
    print(html_output[:500] + "\n... (截断)")

    # 保存到文件
    output_file = Path("preview_demo.html")
    output_file.write_text(html_output, encoding="utf-8")
    print(f"\n✅ HTML 已保存到: {output_file.absolute()}")

    # 如果有 markdown 库，也展示库版本
    try:
        import markdown
        print(f"\n📦 检测到 markdown 库 v{markdown.__version__}——生产环境建议使用")
    except ImportError:
        print("\n💡 提示：pip install markdown 获得生产级 Markdown 解析体验")
