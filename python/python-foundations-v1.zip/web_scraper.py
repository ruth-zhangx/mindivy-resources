#!/usr/bin/env python3
"""Web Scraper — 网页抓取工具

抓取网页内容并提取结构化信息，涵盖以下核心概念：
  - urllib/requests — HTTP 请求
  - BeautifulSoup4 — HTML 解析（可选依赖）
  - 正则表达式 — 文本提取的瑞士军刀
  - 异常处理 — 网络请求的防御性编程

学习路径：
  1. 理解 HTTP GET 请求和响应
  2. html.parser 标准库方案（零依赖）
  3. BeautifulSoup 方案（更强大的选择器）
  4. 异常处理——网络不稳定的应对策略
"""

import html.parser
import re
import time
import urllib.request
import urllib.error
from pathlib import Path
from typing import Any
from urllib.parse import urlparse, urljoin


# ── 1. 网络请求：获取网页内容 ────────────────────────────────────────


def fetch_page(url: str, timeout: int = 10) -> tuple[str, dict[str, str]]:
    """获取网页的 HTML 内容。

    使用 urllib.request——Python 标准库自带的 HTTP 客户端。
    比 requests 库更底层，但零依赖。关键步骤：
      1. 设置 User-Agent（否则很多网站会拒绝请求）
      2. 设置超时（防止永久等待）
      3. 处理重定向（urllib 默认自动跟随）

    Args:
        url: 网页 URL。
        timeout: 请求超时秒数。

    Returns:
        (html_content, headers) 二元组：
          - html_content: HTML 文本
          - headers: 响应头字典（Content-Type, Server 等）

    Raises:
        ValueError: URL 格式无效。
        ConnectionError: 网络不可达。
        TimeoutError: 请求超时。
        urllib.error.HTTPError: HTTP 错误（404, 500 等）。
    """
    # URL 格式校验
    parsed = urlparse(url)
    if not parsed.scheme or not parsed.netloc:
        raise ValueError(f"URL 格式无效: {url}（需要 http:// 或 https:// 前缀）")

    # 构建请求——设置 User-Agent 模拟浏览器
    request = urllib.request.Request(
        url,
        headers={
            "User-Agent": (
                "Mozilla/5.0 (compatible; PythonLearningBot/1.0; "
                "+https://github.com/mindivy/learn-python)"
            ),
            "Accept": "text/html,application/xhtml+xml",
            "Accept-Language": "zh-CN,en;q=0.9",
        },
    )

    try:
        response = urllib.request.urlopen(request, timeout=timeout)
    except urllib.error.HTTPError as e:
        # HTTP 错误：404 Not Found, 500 Internal Server Error 等
        raise urllib.error.HTTPError(
            e.url, e.code, f"HTTP {e.code}: {e.reason}", e.hdrs, e.fp
        ) from e
    except urllib.error.URLError as e:
        # 网络层错误：DNS 解析失败、连接拒绝、超时等
        if "timed out" in str(e.reason).lower():
            raise TimeoutError(f"请求超时 ({timeout}s): {url}") from e
        raise ConnectionError(f"无法连接到 {url}: {e.reason}") from e

    # 从响应头推断编码
    content_type = response.headers.get("Content-Type", "")
    charset = "utf-8"
    if "charset=" in content_type:
        charset = content_type.split("charset=")[-1].split(";")[0].strip()

    html = response.read().decode(charset, errors="replace")
    headers = dict(response.headers)
    return html, headers


# ── 2. HTML 解析：提取结构化信息 ─────────────────────────────────────


class LinkExtractor(html.parser.HTMLParser):
    """从 HTML 中提取所有链接的解析器。

    继承自 html.parser.HTMLParser——Python 标准库的 HTML 解析器。
    它是 SAX 风格（事件驱动）：遇到标签时调用 handle_starttag，
    遇到文本时调用 handle_data，不需要把整个 DOM 加载到内存。

    对比：BeautifulSoup 是 DOM 风格——先构建完整树，再查询。
    HTMLParser 更轻量，但代码更冗长。
    """

    def __init__(self):
        super().__init__()
        self.links: list[dict[str, str]] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]):
        """遇到开始标签时被调用。

        HTMLParser 对每个开启标签（如 <a href="...">, <img src="...">）
        调用这个方法，传入标签名和属性列表。

        Args:
            tag: 标签名（已转为小写）。
            attrs: 属性列表 [(name, value), ...]。
        """
        attrs_dict = {k: v for k, v in attrs if v is not None}

        if tag == "a":
            href = attrs_dict.get("href", "").strip()
            if href and not href.startswith("#"):  # 跳过大标题锚点
                self.links.append({
                    "type": "link",
                    "url": href,
                    "text": "",  # 文本在 handle_data 中处理
                })

        elif tag == "img":
            src = attrs_dict.get("src", "").strip()
            alt = attrs_dict.get("alt", "")
            if src:
                self.links.append({
                    "type": "image",
                    "url": src,
                    "text": alt,
                })

    def handle_data(self, data: str):
        """遇到文本内容时被调用。

        记录最后一个链接的文本——用于提取 <a>text</a> 中的 text。
        """
        text = data.strip()
        if text and self.links and self.links[-1]["type"] == "link":
            # 第一个有意义的文本作为链接文本
            if not self.links[-1]["text"]:
                self.links[-1]["text"] = text


def extract_text(html_content: str) -> str:
    """从 HTML 中提取纯文本（去除所有标签）。

    用正则表达式实现——比 HTMLParser 更快，但会丢失语义结构。
    生产环境建议用 BeautifulSoup 的 .get_text()。

    两步法：
      1. 删 <script> 和 <style> 内容（它们不是可见文本）
      2. 删所有 HTML 标签，保留文本
    """
    # 删除 script 和 style 元素及其内容
    text = re.sub(
        r'<(script|style)[^>]*>.*?</\1>',
        '',
        html_content,
        flags=re.DOTALL | re.IGNORECASE,
    )

    # 删除所有 HTML 标签
    text = re.sub(r'<[^>]+>', '', text)

    # 清理空白：多个连续空白 → 单个空格
    text = re.sub(r'\s+', ' ', text).strip()

    # 解码 HTML 实体：&amp; → &, &lt; → <, &#20013; → 中
    text = html.unescape(text)

    return text


def find_emails(text: str) -> list[str]:
    """从文本中提取邮箱地址。

    邮箱的正则表达式是经典的「够用但不完美」案例——
    完全符合 RFC 5322 的正则需要好几页，但这个覆盖 99% 的实际使用场景。
    """
    pattern = r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'
    return list(set(re.findall(pattern, text)))  # set 去重


def find_phone_numbers(text: str) -> list[str]:
    """从文本中提取中国手机号（1 开头的 11 位数字）。"""
    pattern = r'1[3-9]\d{9}'
    return list(set(re.findall(pattern, text)))


# ── 3. 组装：完整的抓取流程 ──────────────────────────────────────────


def scrape(url: str, extract_contacts: bool = True) -> dict[str, Any]:
    """抓取网页并提取结构化信息。

    完整的抓取流程：下载 → 解析 → 提取

    Args:
        url: 目标网页 URL。
        extract_contacts: 是否提取联系方式（邮箱/电话）。

    Returns:
        包含 url, title, text_preview, links, emails, phones 的字典。
    """
    # Step 1: 下载
    html, headers = fetch_page(url)

    # Step 2: 提取标题
    title_match = re.search(r'<title[^>]*>(.*?)</title>', html, re.IGNORECASE | re.DOTALL)
    title = html.unescape(title_match.group(1).strip()) if title_match else ""

    # Step 3: 提取链接和图片
    extractor = LinkExtractor()
    extractor.feed(html)
    links = extractor.links

    # Step 4: 提取纯文本
    text = extract_text(html)
    text_preview = text[:500]  # 前 500 字预览

    # Step 5: 提取联系方式
    result: dict[str, Any] = {
        "url": url,
        "title": title,
        "text_preview": text_preview,
        "text_length": len(text),
        "link_count": len([l for l in links if l["type"] == "link"]),
        "image_count": len([l for l in links if l["type"] == "image"]),
        "links": links[:20],  # 最多展示 20 个
    }

    if extract_contacts:
        emails = find_emails(text)
        phones = find_phone_numbers(text)
        if emails:
            result["emails"] = emails
        if phones:
            result["phones"] = phones

    return result


# ── 使用示例 ─────────────────────────────────────────────────────────


def demo():
    """演示抓取功能——抓取一个简单的示例页面。"""
    # Python 官网的简单页面（稳定且适合学习）
    url = "https://httpbin.org/html"

    print("=" * 60)
    print(f"🔍 抓取: {url}")
    print("=" * 60)

    try:
        result = scrape(url)
    except (ConnectionError, TimeoutError, urllib.error.HTTPError) as e:
        print(f"❌ 抓取失败: {e}")
        return

    print(f"📄 标题: {result['title']}")
    print(f"📝 文本长度: {result['text_length']} 字符")
    print(f"🔗 链接数: {result['link_count']}")
    print(f"🖼️  图片数: {result['image_count']}")
    print()
    print("前 200 字预览:")
    print("-" * 40)
    print(result["text_preview"][:200])

    if "emails" in result:
        print(f"\n📧 发现的邮箱: {result['emails']}")
    if "phones" in result:
        print(f"\n📱 发现的手机号: {result['phones']}")

    if result["links"]:
        print(f"\n前 5 个链接:")
        for link in result["links"][:5]:
            print(f"  [{link['type']}] {link['text'][:40] or '(图片)'} → {link['url'][:60]}")

    print("\n✅ 演示完成")


if __name__ == "__main__":
    demo()

    # BeautifulSoup 升级提示
    try:
        import bs4
        print(f"\n💡 已安装 BeautifulSoup {bs4.__version__}——建议使用 .select() 做复杂查询")
    except ImportError:
        print("\n💡 提示：pip install beautifulsoup4 获得更强大的 HTML 解析能力")
