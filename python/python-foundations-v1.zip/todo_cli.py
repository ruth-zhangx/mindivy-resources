#!/usr/bin/env python3
"""TODO CLI — 命令行待办事项工具

一个简单的命令行待办事项管理程序，涵盖以下 Python 核心概念：
  - 函数定义与调用
  - 字典 (dict) 的增删改查
  - 文件读写 (json 持久化)
  - 命令行参数解析 (argparse)

学习路径：先看 main() 了解整体流程，再看每个函数的实现细节。
"""

import argparse
import json
import os
from datetime import datetime

# ── 数据层：用 JSON 文件持久化待办事项 ──────────────────────────────

DATA_FILE = "todos.json"


def load_todos() -> list[dict]:
    """从 JSON 文件加载待办事项列表。

    Returns:
        list[dict]: 每个 dict 包含 id, title, done, created_at 字段。
        如果文件不存在，返回空列表（不报错——这是正常的初始状态）。
    """
    if not os.path.exists(DATA_FILE):
        return []
    with open(DATA_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def save_todos(todos: list[dict]) -> None:
    """将待办事项列表保存到 JSON 文件。

    Args:
        todos: 待保存的待办事项列表。

    注意：这里直接覆盖整个文件——对于小数据量这是最简单可靠的方案。
    大数据量时可以考虑增量写入或使用 SQLite。
    """
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(todos, f, ensure_ascii=False, indent=2)


# ── 业务逻辑：待办事项的 CRUD 操作 ──────────────────────────────────


def add_todo(title: str) -> dict:
    """添加一条新的待办事项。

    Args:
        title: 待办事项的标题。

    Returns:
        新创建的待办事项 dict。

    设计要点：
      - 用当前时间戳作为 ID（简单但有效——实际项目可用 UUID）
      - created_at 用 ISO 格式存储（可读性好，便于调试）
    """
    todos = load_todos()
    todo = {
        "id": datetime.now().strftime("%Y%m%d%H%M%S%f"),
        "title": title,
        "done": False,
        "created_at": datetime.now().isoformat(),
    }
    todos.append(todo)
    save_todos(todos)
    return todo


def list_todos(show_all: bool = False) -> list[dict]:
    """列出待办事项。

    Args:
        show_all: True 时显示所有事项（包括已完成的），False 时仅显示未完成的。

    Returns:
        过滤后的待办事项列表。
    """
    todos = load_todos()
    if show_all:
        return todos
    return [t for t in todos if not t["done"]]
    # 上面这行是「列表推导式」（list comprehension）——Python 中最常用的
    # 数据过滤模式。等价于：
    #   result = []
    #   for t in todos:
    #       if not t["done"]:
    #           result.append(t)


def mark_done(todo_id: str) -> dict | None:
    """将指定待办事项标记为已完成。

    Args:
        todo_id: 待办事项的 ID。

    Returns:
        更新后的 todo dict，如果 ID 不存在则返回 None。

    设计要点：
      - 返回 None 让调用方决定如何处理"找不到"的情况
      - 就地修改然后全量保存（简单但非原子——生产环境需要锁或事务）
    """
    todos = load_todos()
    for todo in todos:
        if todo["id"] == todo_id:
            todo["done"] = True
            save_todos(todos)
            return todo
    return None


def delete_todo(todo_id: str) -> bool:
    """删除指定待办事项。

    Args:
        todo_id: 待删除的待办事项 ID。

    Returns:
        True 表示删除成功，False 表示 ID 不存在。

    设计要点：
      - 列表的 remove() 方法按值匹配——这里用列表推导式更灵活
      - 新列表的长度判断是确认删除是否生效的简洁方式
    """
    todos = load_todos()
    new_todos = [t for t in todos if t["id"] != todo_id]
    if len(new_todos) == len(todos):
        return False  # 没有找到匹配的 ID
    save_todos(new_todos)
    return True


# ── 命令行接口：argparse 解析用户输入 ───────────────────────────────


def main():
    """程序入口——解析命令行参数，分发到对应的处理函数。

    argparse 是 Python 标准库的命令行解析器。它自动生成 --help 输出，
    支持位置参数、可选参数、子命令等。下面用的是「子命令」模式——
    每个操作（add/list/done/delete）是一个独立的子命令。
    """
    parser = argparse.ArgumentParser(
        description="TODO CLI — 命令行待办事项管理",
    )
    subparsers = parser.add_subparsers(dest="command", help="可用命令")

    # add 子命令
    add_parser = subparsers.add_parser("add", help="添加待办事项")
    add_parser.add_argument("title", help="待办事项标题")

    # list 子命令
    list_parser = subparsers.add_parser("list", help="列出待办事项")
    list_parser.add_argument(
        "-a", "--all", action="store_true", help="显示所有（包括已完成）"
    )

    # done 子命令
    done_parser = subparsers.add_parser("done", help="标记为已完成")
    done_parser.add_argument("id", help="待办事项 ID")

    # delete 子命令
    delete_parser = subparsers.add_parser("delete", help="删除待办事项")
    delete_parser.add_argument("id", help="待办事项 ID")

    args = parser.parse_args()

    # 根据子命令分发——这是命令模式（Command Pattern）的简单实现
    if args.command == "add":
        todo = add_todo(args.title)
        print(f"✅ 已添加: [{todo['id']}] {todo['title']}")

    elif args.command == "list":
        todos = list_todos(show_all=args.all)
        if not todos:
            print("📭 没有待办事项")
        else:
            for t in todos:
                status = "✅" if t["done"] else "⬜"
                print(f"  {status} [{t['id']}] {t['title']}")

    elif args.command == "done":
        todo = mark_done(args.id)
        if todo:
            print(f"✅ 已完成: {todo['title']}")
        else:
            print(f"❌ 未找到 ID: {args.id}")

    elif args.command == "delete":
        ok = delete_todo(args.id)
        if ok:
            print(f"🗑️  已删除: {args.id}")
        else:
            print(f"❌ 未找到 ID: {args.id}")

    else:
        parser.print_help()


if __name__ == "__main__":
    main()
