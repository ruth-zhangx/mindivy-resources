#!/usr/bin/env python3
"""Testing Guide — pytest 测试入门到实践

从零学习 Python 测试：编写测试、使用 fixture、mock 外部依赖、参数化测试。
涵盖以下核心概念：
  - pytest 基本用法（test_ 前缀、assert 断言）
  - fixture — 测试的依赖注入
  - mock — 隔离外部依赖
  - 参数化测试 — 用数据驱动测试
  - 测试覆盖率 — 衡量测试质量

学习路径：
  1. 第一个测试——理解 test_ 命名约定和 assert
  2. fixture——setUp/tearDown 的现代替代
  3. mock——替换外部 API/数据库/时间
  4. 参数化——一组输入对应一组期望输出
  5. 最佳实践——AAA 模式、测试命名、什么不该测
"""

import json
import math
from pathlib import Path
from typing import Any

# ── 被测试的代码：一个简单的用户管理模块 ────────────────────────────
#
# 在实际项目中，这些函数在另一个文件中，测试文件通过 import 引入。
# 这里放在同一个文件是为了方便阅读——你可以直接看到「被测试的代码」
# 和「测试代码」的关系。


class UserDB:
    """用户数据库（JSON 文件持久化）。

    这是典型的「有副作用的模块」——读写文件系统。
    测试时需要 mock 掉文件操作，避免测试互相干扰。
    """

    def __init__(self, filepath: str = "users.json"):
        self.filepath = Path(filepath)

    def load(self) -> list[dict[str, Any]]:
        """加载所有用户。文件不存在时返回空列表。"""
        if not self.filepath.exists():
            return []
        return json.loads(self.filepath.read_text(encoding="utf-8"))

    def save(self, users: list[dict[str, Any]]) -> None:
        """保存用户列表到文件。"""
        self.filepath.write_text(
            json.dumps(users, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    def get_by_email(self, email: str) -> dict[str, Any] | None:
        """根据邮箱查找用户。"""
        for user in self.load():
            if user.get("email") == email:
                return user
        return None

    def create(self, name: str, email: str, age: int = 0) -> dict[str, Any]:
        """创建新用户。邮箱已存在时抛出 ValueError。"""
        if self.get_by_email(email) is not None:
            raise ValueError(f"邮箱已存在: {email}")
        if age < 0:
            raise ValueError(f"年龄不能为负数: {age}")

        users = self.load()
        user = {
            "id": len(users) + 1,
            "name": name,
            "email": email,
            "age": age,
        }
        users.append(user)
        self.save(users)
        return user


def validate_email(email: str) -> bool:
    """验证邮箱格式。

    注意：这是一个「纯函数」——无副作用，输入决定输出。
    纯函数是最容易测试的函数类型。
    """
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return bool(__import__('re').match(pattern, email))


def calculate_age_stats(users: list[dict[str, Any]]) -> dict[str, float]:
    """计算用户年龄统计。

    又是一个纯函数——输入一串用户，输出统计值。
    测试纯函数时不需要 mock 任何东西。
    """
    ages = [u.get("age", 0) for u in users if u.get("age", 0) > 0]
    if not ages:
        return {"count": 0}

    return {
        "count": len(ages),
        "average": sum(ages) / len(ages),
        "min": min(ages),
        "max": max(ages),
    }


# ── pytest 测试 (用 pytest 运行: $ pytest testing_guide.py) ─────────
#
# 运行方式：
#   pytest testing_guide.py           # 全部测试
#   pytest testing_guide.py -v        # 详细输出
#   pytest testing_guide.py -k test_validate_email  # 只运行匹配的测试
#   pytest testing_guide.py --tb=short  # 简短的错误回溯


class TestValidateEmail:
    """测试邮箱验证函数。

    测试类命名：Test 前缀（pytest 约定）。
    类中的每个 test_ 方法会被当作独立的测试用例。
    用类分组可以让测试更有组织——相关的测试放在一起。
    """

    def test_valid_email(self):
        """有效的邮箱应该返回 True。

        测试命名建议：test_<被测函数>_<场景>_<期望结果>。
        好的测试名在读失败报告时价值巨大——你不需要看代码
        就能知道什么场景出了问题。
        """
        assert validate_email("alice@example.com") is True
        assert validate_email("bob123@test.co.uk") is True

    def test_invalid_email_missing_at(self):
        """缺少 @ 符号的邮箱应该返回 False。"""
        assert validate_email("aliceexample.com") is False

    def test_invalid_email_empty(self):
        """空字符串应该返回 False。"""
        assert validate_email("") is False

    def test_invalid_email_no_domain(self):
        """缺少域名的邮箱应该返回 False。"""
        assert validate_email("alice@") is False


class TestCalculateAgeStats:
    """测试年龄统计函数。

    遵循 AAA 模式（Arrange-Act-Assert）：
      1. Arrange: 准备测试数据
      2. Act: 执行被测函数
      3. Assert: 验证结果
    """

    def test_normal_case(self):
        """正常输入——多个用户有不同年龄。"""
        # Arrange
        users = [
            {"name": "A", "age": 20},
            {"name": "B", "age": 30},
            {"name": "C", "age": 40},
        ]

        # Act
        result = calculate_age_stats(users)

        # Assert
        assert result["count"] == 3
        assert result["average"] == 30.0
        assert result["min"] == 20
        assert result["max"] == 40

    def test_empty_list(self):
        """空列表——边界情况测试。"""
        result = calculate_age_stats([])
        assert result == {"count": 0}

    def test_missing_age_field(self):
        """某些用户缺少 age 字段——应被跳过而非崩溃。"""
        users = [
            {"name": "A", "age": 25},
            {"name": "B"},  # 无 age
        ]
        result = calculate_age_stats(users)
        assert result["count"] == 1
        assert result["average"] == 25.0

    def test_all_zero_age(self):
        """所有用户 age=0——应被排除（视为未设置）。"""
        users = [
            {"name": "A", "age": 0},
            {"name": "B", "age": 0},
        ]
        result = calculate_age_stats(users)
        assert result == {"count": 0}


# ── Fixture 示例（需要 pytest 运行）───────────────────────────────────
#
# Fixture 是 pytest 最强大的特性之一——它是测试的依赖注入系统。
# 对比 unittest 的 setUp/tearDown：
#   - fixture 可以在不同 scope（函数/类/模块/会话）复用
#   - fixture 可以依赖其他 fixture（链式注入）
#   - fixture 可以做 teardown（用 yield 而非 return）


# 在真实测试文件中，下面这些函数去掉注释即可使用：

# import pytest
#
#
# @pytest.fixture
# def sample_users():
#     """提供一组示例用户数据。
#
#     这是一个函数级 fixture（默认 scope="function"）——
#     每个测试函数调用它时都会重新执行。
#     """
#     return [
#         {"id": 1, "name": "Alice", "email": "alice@test.com", "age": 25},
#         {"id": 2, "name": "Bob", "email": "bob@test.com", "age": 30},
#     ]
#
#
# @pytest.fixture
# def temp_db(tmp_path):
#     """使用 pytest 内置的 tmp_path fixture 创建临时数据库。
#
#     tmp_path 是 pytest 提供的内置 fixture——
#     自动创建一个临时目录，测试结束后自动清理。
#     这比手动创建和删除文件可靠得多。
#     """
#     db_path = tmp_path / "test_users.json"
#     db = UserDB(str(db_path))
#     yield db  # yield 之前是 setUp，之后是 tearDown
#     # 测试结束后 tmp_path 自动清理——不需要手动删除文件
#
#
# def test_create_user(temp_db, sample_users):
#     """测试创建用户——使用 temp_db 和 sample_users 两个 fixture。"""
#     temp_db.save(sample_users)
#     user = temp_db.create("Charlie", "charlie@test.com", age=28)
#     assert user["name"] == "Charlie"
#     assert len(temp_db.load()) == 3
#
#
# def test_create_duplicate_email(temp_db, sample_users):
#     """测试重复邮箱——应抛出 ValueError。
#
#     pytest.raises 是测试异常的上下文管理器。
#     如果 with 块内的代码没有抛出指定异常，测试失败。
#     """
#     temp_db.save(sample_users)
#     with pytest.raises(ValueError, match="邮箱已存在"):
#         temp_db.create("Alice Clone", "alice@test.com")


# ── Mock 示例（需要 pytest + pytest-mock 或 unittest.mock）───────────
#
# Mock 的核心哲学：测试应该测试「你自己的逻辑」，
# 而不是测试外部 API、数据库、文件系统是否正常。


# from unittest.mock import patch, Mock
#
#
# def test_fetch_user_from_api(mocker):
#     """Mock 外部 API 调用。
#
#     假设 fetch_user_from_api() 内部调用了 requests.get()——
#     我们不希望测试真的发送 HTTP 请求（太慢、不稳定）。
#     用 mocker.patch 替换 requests.get，让它返回预制的响应。
#     """
#     mock_response = Mock()
#     mock_response.json.return_value = {"id": 1, "name": "Alice"}
#     mock_response.status_code = 200
#
#     with patch("requests.get", return_value=mock_response):
#         user = fetch_user_from_api(user_id=1)
#
#     assert user["name"] == "Alice"
#     # 还可以验证 requests.get 被调用了正确的参数：
#     # mock_get.assert_called_once_with("https://api.example.com/users/1")


# ── 参数化测试示例 ────────────────────────────────────────────────────
#
# 参数化让你用同样的测试逻辑覆盖多个输入——不需要写重复的测试函数。


# @pytest.mark.parametrize("email,expected", [
#     ("alice@example.com", True),
#     ("bob@test.co.uk", True),
#     ("not-an-email", False),
#     ("", False),
#     ("@missing-user.com", False),
#     ("spaces in@email.com", False),
# ])
# def test_validate_email_parametrized(email, expected):
#     """一条参数化测试覆盖 6 个场景。
#
#     pytest 会为每组参数生成独立的测试用例：
#       test_validate_email_parametrized[alice@example.com-True]
#       test_validate_email_parametrized[not-an-email-False]
#       ...
#     失败时立即知道哪组输入出了问题。
#     """
#     assert validate_email(email) == expected


# ── 测试最佳实践 ──────────────────────────────────────────────────────


def print_testing_best_practices():
    """关于 Python 测试的最佳实践。"""
    tips = """
╔══════════════════════════════════════════════════════════════╗
║              Python 测试最佳实践                              ║
╠══════════════════════════════════════════════════════════════╣
║                                                              ║
║  1. AAA 模式：Arrange → Act → Assert                         ║
║     每个测试三部分清晰分离，用空行隔开                          ║
║                                                              ║
║  2. 一个测试只验证一件事                                       ║
║     好的测试：test_create_user_success                        ║
║     坏的测试：test_user_module_everything                     ║
║                                                              ║
║  3. 测试命名：test_<what>_<scenario>_<expected>               ║
║     从失败报告就能知道「什么」「在什么情况下」「出什么问题」     ║
║                                                              ║
║  4. 不要测试实现细节                                          ║
║     测试「行为」而非「代码」——重构不应破坏测试                 ║
║                                                              ║
║  5. 不要 mock 你不拥有的接口                                  ║
║     永远 mock requests.get 而非内部函数                       ║
║                                                              ║
║  6. Fixture 优于 setUp/tearDown                               ║
║     可组合、可复用、作用域可控                                ║
║                                                              ║
║  7. 测试覆盖率 > 80% 是理想目标                               ║
║     但 100% 覆盖 ≠ 无 bug——更重要的是边界用例                 ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
"""
    print(tips)


# ── 使用示例 ─────────────────────────────────────────────────────────

if __name__ == "__main__":
    print("=" * 60)
    print("Testing Guide — 演示（非 pytest 运行）")
    print("=" * 60)

    # 手动验证 validate_email
    print("\n📧 邮箱验证测试:")
    test_cases = [
        ("alice@example.com", True),
        ("not-an-email", False),
        ("", False),
        ("a@b.c", True),
    ]
    for email, expected in test_cases:
        result = validate_email(email)
        status = "✅" if result == expected else "❌"
        print(f"  {status} {email!r:30} → {result} (期望 {expected})")

    # 手动验证 calculate_age_stats
    print("\n📊 年龄统计测试:")
    users = [
        {"name": "Alice", "age": 25},
        {"name": "Bob", "age": 35},
        {"name": "Charlie", "age": 30},
    ]
    stats = calculate_age_stats(users)
    print(f"  输入: {len(users)} 用户")
    print(f"  结果: {stats}")
    assert stats["average"] == 30.0, f"期望 30.0，得到 {stats['average']}"
    print("  ✅ 平均值测试通过")

    print_testing_best_practices()

    print("\n💡 用 pytest 运行本文件：")
    print("   pip install pytest")
    print("   pytest testing_guide.py -v")
