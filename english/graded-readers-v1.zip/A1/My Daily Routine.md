# My Daily Routine

> Level: A1 | Words: 130 | Source: Original (daily life)

I wake up at seven o'clock every morning. First, I wash my face and brush my teeth. Then, I eat breakfast. I usually have bread with butter and a glass of milk.

I leave home at eight o'clock. I walk to the bus stop and take the bus to work. The bus ride takes about twenty minutes.

I work from nine to five. At noon, I eat lunch with my friends. We often talk about our weekends and plans.

After work, I go to the gym two times a week. On other days, I go straight home. I cook dinner and watch some TV. Before bed, I like to read for about thirty minutes. I go to sleep at eleven o'clock.

On weekends, I sleep later. I spend time with my family and do the shopping for the week.