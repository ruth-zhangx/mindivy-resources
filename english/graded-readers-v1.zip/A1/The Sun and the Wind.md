# The Sun and the Wind

> Level: A1 | Words: 142 | Source: Aesop's Fables (simplified)

The sun and the wind were arguing. "I am stronger than you," said the wind. "No, I am stronger," said the sun.

They saw a man walking down the road. He was wearing a coat.

"Let us have a test," said the sun. "Whoever can make the man take off his coat is the stronger one."

The wind went first. He blew as hard as he could. But the man held his coat tighter. The wind blew harder, but the man only held on more.

Then the sun came out. He shone warmly on the man. The man felt hot. He took off his coat.

Moral: Kindness and warmth work better than force.