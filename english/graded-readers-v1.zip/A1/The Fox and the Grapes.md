# The Fox and the Grapes

> Level: A1 | Words: 95 | Source: Aesop's Fables (simplified)

A hungry fox saw some grapes hanging from a vine. The grapes looked big and sweet. The fox wanted to eat them very much.

He jumped up, but he could not reach the grapes. He jumped again and again. Each time he failed.

At last, the fox stopped trying. He walked away and said, "Those grapes are probably sour anyway. I do not want them."

Moral: It is easy to dislike what you cannot have.