# The Hare and the Tortoise

> Level: A1 | Words: 145 | Source: Aesop's Fables (simplified)

A hare was always laughing at a tortoise because he walked so slowly. "You are the slowest animal in the world," the hare said. The tortoise smiled and said, "Let us have a race. I think I can beat you."

The hare laughed even more. "This will be the easiest race of my life," he said. The race began. The hare ran very fast. Soon, he was far ahead of the tortoise. He decided to take a nap under a tree.

Meanwhile, the tortoise kept walking. He did not stop. He did not rest. He walked slowly but steadily past the sleeping hare.

When the hare woke up, the tortoise was almost at the finish line. The hare ran as fast as he could, but it was too late. The tortoise won the race.

Moral: Slow and steady wins the race.