# The Ant and the Dove

> Level: A1 | Words: 123 | Source: Aesop's Fables (simplified)

An ant went down to the river to drink. He fell into the water and could not get out. A dove sat on a tree above the river. She saw the ant and dropped a leaf into the water. The ant climbed onto the leaf and was safe.

Later, a hunter came. He wanted to catch the dove. The ant saw the hunter. He bit the hunter's foot. The hunter shouted in pain. The dove heard the noise and flew away.

Moral: One good turn deserves another.