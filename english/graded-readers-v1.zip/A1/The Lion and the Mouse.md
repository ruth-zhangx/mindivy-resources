# The Lion and the Mouse

> Level: A1 | Words: 187 | Source: Aesop's Fables (simplified)

A lion was sleeping in the forest. A little mouse ran across his nose. The lion woke up and caught the mouse. He was about to eat her.

The mouse said, "Please let me go. One day I will help you."

The lion laughed. "You are so small. How can you help me?" But he let the mouse go.

A few days later, the lion was caught in a hunter's net. He could not get free. He roared for help.

The mouse heard the lion's roar. She ran to help. She bit through the ropes with her sharp teeth. The lion was free.

"Thank you, little mouse," said the lion. "You did help me after all."

Moral: Even small friends can be great friends.