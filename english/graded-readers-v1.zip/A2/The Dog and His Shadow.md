# The Dog and His Shadow

> Level: A2 | Words: 102 | Source: Aesop's Fables (simplified)

A dog was walking home with a piece of meat in his mouth. He had to cross a small bridge over a stream. As he walked across, he looked down into the water.

In the water, he saw another dog with a piece of meat in its mouth. The dog did not understand that it was his own shadow.

He wanted both pieces of meat. He opened his mouth to bark at the other dog. As soon as he opened his mouth, his meat fell into the water and was carried away by the stream.

Moral: If you want too much, you may lose everything.