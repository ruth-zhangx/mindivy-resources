# The Town Mouse and the Country Mouse

> Level: A2 | Words: 224 | Source: Aesop's Fables (simplified)

A town mouse came to visit his cousin in the country. The country mouse gave him a simple meal of corn and beans.

"This is how you live?" asked the town mouse. "Come with me to the town. I will show you good food."

They went to the town. The town mouse took his cousin to a big house. There was bread, cheese, fruit, and sweet honey on the table.

Just as they began to eat, the door opened. Two people came in. The mice ran away in fear.

Later, they tried again. This time, a cat jumped at them. Again they ran.

"I am going home," said the country mouse. "Your food is fine, but I like my simple, quiet life better than your rich, dangerous one."

Moral: A simple, peaceful life is better than a life of luxury filled with fear.