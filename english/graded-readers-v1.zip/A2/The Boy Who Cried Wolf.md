# The Boy Who Cried Wolf

> Level: A2 | Words: 175 | Source: Aesop's Fables (simplified)

A young boy watched the village sheep. Every day, he sat on the hill alone. He was very bored. One day, he thought of a trick. He ran into the village and shouted, "Wolf! Wolf! A wolf is attacking the sheep!"

The villagers ran up the hill to help. But there was no wolf. The boy laughed. "It was just a joke," he said. The villagers were angry.

A few days later, the boy did it again. "Wolf! Wolf!" he cried. The villagers came running once more. Again, there was no wolf. The villagers shook their heads and went home.

One day, a real wolf came. It began eating the sheep. The boy shouted, "Wolf! Wolf! Please help!" But no one came. The villagers thought it was another trick. The wolf ate many sheep that day.

Moral: No one believes a liar, even when they tell the truth.