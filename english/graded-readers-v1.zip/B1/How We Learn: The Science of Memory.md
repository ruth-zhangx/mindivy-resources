# How We Learn: The Science of Memory

> Level: B1 | Words: 210 | Source: Educational content (original)

Learning happens when your brain makes connections between brain cells called neurons. Every time you learn something new, these connections become stronger. Scientists call this process neuroplasticity.

There are two main types of memory. Short-term memory holds information for about 20 to 30 seconds. For example, when you look at a phone number and try to remember it just long enough to write it down.

Long-term memory can store information for days, months, or even a lifetime. But not everything in short-term memory moves to long-term memory. Your brain decides what is important based on how often you use the information and how strong your feelings are when you learn it.

The best way to move information into long-term memory is through spaced repetition. This means reviewing what you have learned at longer and longer intervals. When you learn a new word today, review it tomorrow, then in three days, then in a week. Each review makes the memory stronger.

Another important technique is active recall. Instead of just reading your notes again, try to remember the information without looking. This is much more effective than passive review.