# The Water Cycle

> Level: B1 | Words: 180 | Source: Educational content (original)

Water on Earth is always moving. It travels from the oceans to the sky, from the sky to the land, and from the land back to the oceans. Scientists call this journey the water cycle.

The sun heats the surface of the ocean. This turns liquid water into water vapor — a gas that rises into the air. This process is called evaporation. Plants also release water vapor through their leaves, which is called transpiration.

As the water vapor rises, it cools down. It turns back into tiny drops of liquid water. These drops form clouds. When the drops become too heavy, they fall as rain or snow. This is called precipitation.

Some rainwater flows into rivers and streams. This is called runoff. Some rainwater goes underground and becomes groundwater. In both cases, the water eventually finds its way back to the ocean. And the cycle begins again.

The water cycle has been working the same way for billions of years. Every drop of water you drink today may have once been part of a dinosaur, an ancient ocean, or a cloud over a distant mountain.